﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Hbase.Test;

namespace Lib.Hbase.Thrift2.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            HClient.FistTest();
        }
    }
}
